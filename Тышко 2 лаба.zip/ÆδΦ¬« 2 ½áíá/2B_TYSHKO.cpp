﻿// 2B_TYSHKO.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//

#include <iostream>
#include <fstream>
#include <windows.h>
#include <cmath>
#include <thread>
#include <queue>
#include <vector>

using namespace std;

CRITICAL_SECTION taskQueue;
CRITICAL_SECTION writeResult;
CRITICAL_SECTION writeThread;

struct Parameters
{
    double a;
    double b;
    double eps;
};

struct Result
{
    Parameters parameters;
    double I = 0;
    double time = 0;
};

struct dataThread
{
    int completedTaskCounter = 0;
    double workTime = 0;
};

queue <Parameters> qTask;
vector <Result> vResult;
vector <dataThread> vThread;

int TaskCount(0), ThreadCount(0), completed(0), error(0), noSolution(0);

double function(double x)
{
    return (x - 3) / (3 + pow(x, 2));
}

void print() 
{
    ofstream fout("output.txt");
    if (fout.is_open())
    {
        for (int i = 1; i <= TaskCount; i++)
        {
            fout << i << " Integral: \n";
            fout << " a = " << vResult[i - 1].parameters.a << endl
                << " b = " << vResult[i - 1].parameters.b << endl
                << " eps = " << vResult[i - 1].parameters.eps << endl;
            fout << "Result: " << vResult[i - 1].I << endl << endl;
        }
    }
    fout.close();
}

void sort()
{
    sort(vThread.begin(), vThread.end(), [](dataThread lhs, dataThread rhs)->bool
        {
            return lhs.workTime > rhs.workTime;
        }
    );
}


void simpson(Parameters &parameters, Result &result)
{
    double I1 = parameters.eps + 1;
    double I2 = 0;
    for (int n = 2; (n <= 4) || (fabs(I2 - I1) > parameters.eps); n *= 2)
    {

        double h, s1(0), s2(0), s3(0);
        h = (parameters.b - parameters.a) / (2 * n);

        for (int i = 1; i <= 2 * n - 1; i += 2)
        {
            s3 += function(parameters.a + h * i);
            s2 += function(parameters.a + h * (i + 1));
        }

        s1 = function(parameters.a) + 4 * s3 + 2 * s2 - function(parameters.b);
        I1 = I2;
        I2 = (h / 3) * s1;
        result.parameters = parameters;
        result.I = I2;
    }
}

void startThread() 
{
    dataThread th;
    while (true) 
    {
        Parameters parameters;

        bool flag = 1;
        EnterCriticalSection(&taskQueue);
        if (!qTask.empty())
        {
            parameters = qTask.front();
            qTask.pop();
            flag = 0;
        }
        LeaveCriticalSection(&taskQueue);
        if (flag) 
            break;
        completed++;

        Result result;
        int start = clock();
        simpson(parameters, result);
        result.time = clock() - start;

        th.workTime += result.time;
        th.completedTaskCounter ++;

        EnterCriticalSection(&writeResult);
        vResult.push_back(result);
        LeaveCriticalSection(&writeResult);
    }

    EnterCriticalSection(&writeThread);
    vThread.push_back(th);
    LeaveCriticalSection(&writeThread);
}

void random()
{
    srand(time(NULL));
    for (int i = 0; i < TaskCount; i++)
    {
        Parameters p;

        p.a = double((rand() % 6000 - 1000)) / 10;
        p.b = double(rand() % 6000 - 1000) / 10;

        p.eps = pow(10, rand() % 5 - 10);

        qTask.push(p);
    }
}

int main()
{
    InitializeCriticalSection(&taskQueue);
    InitializeCriticalSection(&writeResult);
    InitializeCriticalSection(&writeThread);

    cout << "Task count - ";
    cin >> TaskCount;
    cout << "Thread count - ";
    cin >> ThreadCount;
    cout << endl;

    random();

    auto* threads = new thread[ThreadCount];
    for (int i = 0; i < ThreadCount; i++)
    {
        threads[i] = thread(startThread);
    }
    for (int i = 0; i < ThreadCount; i++)
    {
        if (threads[i].joinable()) 
            threads[i].join();
    }

    int startOut = clock();
    print();
    int timeOut = clock() - startOut;

    cout << "Results:\n";
    cout << "Completed tasks - " << completed << endl;
    cout << "Errors - " << error << endl;
    cout << "Without solution - " << noSolution << endl;
    cout << endl;

    sort();
    for (int i(0); i < ThreadCount; i++) 
    {
        cout << i + 1 << " thread:\nSolved - " << vThread[i].completedTaskCounter << " tasks\n";
        cout << "Elapsed time - " << vThread[i].workTime << " ms\n\n";
    }

    cout << endl;

    cout << "Max time - " << vThread[0].workTime << " ms\n" 
         << "Min time - " << vThread[vThread.size() - 1].workTime << " ms\n" 
         << "Output time - " << timeOut << " ms\n";

    return 0;
}
