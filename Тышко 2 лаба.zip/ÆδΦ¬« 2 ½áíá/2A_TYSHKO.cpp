﻿// 2A_TYSHKO.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//

#include <iostream>
#include <fstream>
#include <cmath>
#include <thread>

using namespace std;

struct Parameters 
{
	double a;
	double b;
	double eps;
};

double function(double x) 
{
	return (x - 3) / (3 + pow(x,2));
}

void startThread(string inf, string outf)
{

	ifstream fin(inf);
	ofstream fout(outf);
	Parameters parameters;
	if (fin.is_open() && fout.is_open())
	{

		fin >> parameters.a >> parameters.b >> parameters.eps;
		if (parameters.eps <= 0)
		{
			fout << "No solution: wrong eps" << endl;
			return;
		}

		double I1 = parameters.eps + 1;
		double I2 = 0;

		for (int n = 2; (n <= 4) || (fabs(I2 - I1) > parameters.eps); n *= 2)
		{

			double h, s1(0), s2(0), s3(0);
			h = (parameters.b - parameters.a) / (2 * n);

			for (int i = 1; i <= 2 * n - 1; i += 2) 
			{
				s3 += function(parameters.a + h * i);
				s2 += function(parameters.a + h * (i + 1));
			}

			s1 = function(parameters.a) + 4 * s3 + 2 * s2 - function(parameters.b);
			I1 = I2;
			I2 = (h / 3) * s1;
		}

		fout << I2 << endl;
	}
	fin.close();
	fout.close();
}

int main()
{
	string inf = "input.txt";
	string outf = "output.txt";

	int time, start = clock();
	thread t(startThread, inf, outf);
	t.join();
	time = clock() - start;

	cout << "Elapsed time: " << time << " ms\n";
	return 0;
}