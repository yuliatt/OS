﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.IO;

namespace OS_LAB_TYSHKO_1A
{
    public partial class Form1 : Form
    {
        public Thread firstThread, secondThread;
        public List<string> firstList = new List<string>();
        public List<string> secondList = new List<string>();
        public string fileName;
        public bool fileSearchFlag = false;
        public string directoryName;
        public bool directorySearchFlag = false;
        public int searchDepth = 1;
        
        
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog fbd = new FolderBrowserDialog();
            fbd.ShowNewFolderButton = false;
            if (fbd.ShowDialog() == DialogResult.OK)
            {
                textBox1.Text = fbd.SelectedPath;
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            directoryName = textBox1.Text;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if (directoryName == null || fileName == null)
                {
                    richTextBox1.AppendText("ДЛЯ НАЧАЛА ПОИСКА НЕ ХВАТАЕТ ДАННЫХ\n");
                    richTextBox2.AppendText("ДЛЯ НАЧАЛА ПОИСКА НЕ ХВАТАЕТ ДАННЫХ\n");
                    return;
                }

                richTextBox1.Clear();
                richTextBox2.Clear();
                firstList.Clear();
                secondList.Clear();

                Invoke(new Action(() => richTextBox1.AppendText("1 ПОТОК: НАЧАЛ ПРОЦЕСС\n")));
                Invoke(new Action(() => richTextBox2.AppendText("2 ПОТОК: НАЧАЛ ПРОЦЕСС\n")));

                recursiveSearch(searchDepth, directoryName);
            }
            catch (Exception ex)
            {
                firstThread.Abort();
                secondThread.Abort();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (firstThread.IsAlive && secondThread.IsAlive)
            {
                Invoke(new Action(() => richTextBox1.AppendText("1 ПОТОК: ЗАВЕРШИЛ ПРОЦЕСС\n")));
                firstThread.Abort();
                Invoke(new Action(() => richTextBox2.AppendText("2 ПОТОК: ЗАВЕРШИЛ ПРОЦЕСС\n")));
                secondThread.Abort();
            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            fileName = textBox3.Text;
        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            fileSearchFlag = checkBox1.AutoCheck;
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            directorySearchFlag = checkBox2.AutoCheck;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void richTextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            searchDepth = int.Parse(comboBox1.Text);
        }

        private void recursiveSearch(int depth, string directory)
        {
            if (depth != 0)
            {
                if (fileSearchFlag || directorySearchFlag)
                {
                    firstThread = new Thread((() => { FirstTread(directory); }));
                    secondThread = new Thread((() => { SecondThread(directory); }));
                    firstThread.Start();
                    secondThread.Start();
                    string[] allfiles;
                    depth--;
                    foreach (string file in allfiles = Directory.GetDirectories(directory))
                        recursiveSearch(depth, file);
                }
            }
        }

        public void FirstTread(string sDirectory)
        {
            try
            {
                if (directorySearchFlag)
                {
                    string[] alldirectory;
                    foreach (string directory in alldirectory = Directory.GetDirectories(sDirectory))
                    {
                        string fileCheck = directory.Substring(directory.LastIndexOf("\\"));
                        if (fileCheck.IndexOf(fileName) >= 0)
                        {
                            firstList.Add(directory);
                            Invoke(new Action(() => richTextBox1.AppendText("1 ПОТОК: НАШЕЛ D - " + directory + "\n")));
                        }
                    }
                }
                if (fileSearchFlag)
                {
                    string[] allfiles;
                    foreach (string file in allfiles = Directory.GetFiles(sDirectory))
                    {
                        string fileCheck = file.Substring(file.LastIndexOf("\\"));
                        if (fileCheck.IndexOf(fileName) >= 0)
                        {
                            firstList.Add(file);
                            Invoke(new Action(() => richTextBox1.AppendText("1 ПОТОК: НАШЕЛ F - " + file + "\n")));
                        }
                    }
                }
            }
            catch (System.UnauthorizedAccessException ex)
            {
                Invoke(new Action(() => richTextBox1.AppendText("1 ПОТОК: РАБОТА в директории " + sDirectory + 
                                                                " ПРЕРВАНА. Попытка доступа в системные файлы\n")));
                if (firstThread.IsAlive && secondThread.IsAlive)
                {
                    firstThread.Abort();
                }
            }

        }

        public void SecondThread(string sDirectory)
        {
            try
            {
                if (directorySearchFlag)
                {
                    string[] alldirectory;
                    foreach (string directory in alldirectory = Directory.GetDirectories(sDirectory))
                    {
                        string fileCheck = directory.Substring(directory.LastIndexOf("\\"));
                        if (fileCheck.IndexOf(fileName) >= 0)
                        {
                            secondList.Add(directory);
                            Invoke(new Action(() => richTextBox2.AppendText("2 ПОТОК: НАШЕЛ D - " + directory + "\n")));
                        }
                    }
                }
                if (fileSearchFlag)
                {
                    string[] allfiles;
                    foreach (string file in allfiles = Directory.GetFiles(sDirectory))
                    {
                        string fileCheck = file.Substring(file.LastIndexOf("\\"));
                        if (fileCheck.IndexOf(fileName) >= 0)
                        {
                            secondList.Add(file);
                            Invoke(new Action(() => richTextBox2.AppendText("2 ПОТОК: НАШЕЛ F - " + file + "\n")));
                        }
                    }
                }
            }
            catch (System.UnauthorizedAccessException ex)
            {
                Invoke(new Action(() => richTextBox2.AppendText("2 ПОТОК: РАБОТА в D - " + sDirectory + 
                                                                " ПРЕРВАНА. Попытка доступа в системные файлы\n")));
                if (firstThread.IsAlive && secondThread.IsAlive)
                {
                    secondThread.Abort();
                }
            }

        }
    }
}
