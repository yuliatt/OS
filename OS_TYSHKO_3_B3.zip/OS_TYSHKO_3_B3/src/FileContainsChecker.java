public class FileContainsChecker {

    boolean isCheckedIn = false;
    boolean isCorrectIn = true;
    boolean isCorrectOut = true;

    boolean isSolved = false;
    boolean isChecked = false;
    boolean NoFound = false;

    int ind;
    FileContainsChecker(int index){

        this.ind = index;
    }

    void print(){
        String msg = "Файл \"solution" + (ind ==0 ? "" : ind) + Main.prefOUT + "\":  ";

        if (NoFound){
            msg += "не найден";
        }
        else if (!isCorrectIn){
            msg += "неверные входные данные";
        }
        else if (!isCorrectOut){
            msg += "неверное решение";
        }
        else{
            msg += "ОК";
        }
        System.err.println(msg);
    }
}
