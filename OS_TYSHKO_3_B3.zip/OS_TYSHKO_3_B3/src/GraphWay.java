import java.io.BufferedWriter;
import java.io.IOException;

public class GraphWay {
    public GraphNode beg;
    public GraphNode end;
    public int wayL;

    GraphWay(){
        beg = null;
        end = null;
        wayL = 0;
    }
    GraphWay(GraphNode beg, GraphNode end, int wayL){
        this.beg = beg;
        this.end = end;
        this.wayL = wayL;
    }
    void print(){
        if (beg == null || end == null);
        else if (wayL == -1) {
            System.out.println("Путь: " + (beg.index+1) + "->" + (end.index+1) + " не существует");
        }
        else{
            System.out.println("Путь: " + (beg.index+1) + "->" + (end.index+1) + " Длина пути: " + wayL);
        }
    }
    void write(BufferedWriter bw) throws IOException {
        if (beg != null && end != null && wayL != -1) {
            bw.write((beg.index + 1) + " " + (end.index + 1) + " " + wayL +'\n');
        }
    }
    boolean lessThen(GraphWay w){
        return this.wayL < w.wayL;
    }
}
