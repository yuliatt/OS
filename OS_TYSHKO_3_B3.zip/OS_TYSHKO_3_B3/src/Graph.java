import java.io.*;
import java.util.*;

public class Graph {
    public GraphNode[] nodes;
    GraphWay[][] graphWays;
    int[][] a;

    int N;
    int L;

    String INpath;
    String SOLUTIONpath;

    FileContainsChecker fileCondition;

    Graph(FileContainsChecker containsChecker, String INpath, String SOLUTIONpath){
        fileCondition = containsChecker;
        this.INpath = INpath;
        this.SOLUTIONpath = SOLUTIONpath;
    }

    void solution() throws IOException {
        System.out.println("Файл: \"in" +fileCondition.ind + Main.prefIN +"\"" );
        readGraph();
        print();
        findAllWays();
        printAllWays();
        writeAllWays();
        fileCondition.isSolved = true;
    }
    void writeAllWays() throws IOException {
        BufferedWriter out = new BufferedWriter(new FileWriter( SOLUTIONpath +
                "solution" + (fileCondition.ind ==0 ? "" : fileCondition.ind) + Main.prefOUT));
        for(int i = 0; i < N; i++){
            for(int j = 0; j < N; j++){
                graphWays[i][j].write(out);
            }
        }
        out.close();
    }

    void printAllWays(){
        for(int i = 0; i < N; i++){
            for(int j = 0; j < N; j++){
                graphWays[i][j].print();
            }
        }
    }
    void findAllWays() throws IOException {
        graphWays = new GraphWay[N][N];
        for(int i = 0; i < N; i++){
            for(int j = 0; j < N; j++){
                if (i==j){
                    graphWays[i][j] = new GraphWay();
                }
                else{
                    graphWays[i][j] = findWay(nodes[i], nodes[j]);
                }
            }
        }

    }
    GraphWay findWay(GraphNode beg, GraphNode end){
        Vector<GraphWay> ways = new Vector<GraphWay>();
        for(int i = 0; i < N; i++){
            if (beg.edges[i].SFway != 0){
                ways.add(new GraphWay(beg, beg.edges[i].finish, beg.edges[i].SFway));
            }
        }
        do{
            int waysSize = ways.size();
            Vector<GraphWay> remove_ways = new Vector<>();
            for (int k = 0; k < waysSize; k++) {
                GraphWay w = ways.get(k);
                boolean del = true;
                for(int i = 0; i < N; i++){
                    if (w.end == end){
                        del = false;
                    }
                    else if (w.end.edges[i].SFway != 0){
                        ways.add(new GraphWay(beg, w.end.edges[i].finish, w.wayL + w.end.edges[i].SFway));
                    }
                }
                if (del){
                    remove_ways.add(w);
                }
            }
            ways.removeIf(w -> w.wayL > L);
            ways.removeIf(w -> w.beg == w.end);
            for (GraphWay rv: remove_ways) {
                ways.removeAll(remove_ways);
            }
            if (ways.isEmpty()){
                return new GraphWay(beg, end, -1);
            }
            boolean allSol = true;
            for (GraphWay w: ways) {
                if (w.end != end) {
                    allSol = false;
                    break;
                }
            }
            if (allSol){
                GraphWay res = ways.firstElement();
                for (GraphWay w: ways) {
                    if (w.lessThen(res)){
                        res = w;
                    }
                }
                return res;
            }
        }while(true);
    }


    GraphNode getNodeByIndex(int index){
        for(int i = 0; i < N; i++){
            if (nodes[i].index == index){
                return nodes[i];
            }
        }
        return null;
    }

    void readGraph() throws IOException {

        BufferedReader reader = new BufferedReader(new FileReader( INpath
                + "in" + (fileCondition.ind ==0 ? "" : fileCondition.ind) + Main.prefIN));
        StringTokenizer NL = new StringTokenizer( reader.readLine() );
        N = Integer.parseInt(NL.nextToken());
        L = Integer.parseInt(NL.nextToken());

        a = new int[N][N];
        nodes = new GraphNode[N];

        for(int i = 0; i < N; i++){
            String line = reader.readLine();
            StringTokenizer st = new StringTokenizer(line);
            for(int j = 0; j < N; j++){
                a[i][j] = Integer.parseInt( st.nextToken() );
            }
        }

        for (int i = 0; i < N; i++) {
            nodes[i] = new GraphNode(i, N);
        }
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                nodes[i].initialiseEdge( getNodeByIndex(j), j, a[i][j]);
            }
        }
        reader.close();
    }

    void print(){
        for (GraphNode node:nodes) {
            node.print();
        }
    }
}
