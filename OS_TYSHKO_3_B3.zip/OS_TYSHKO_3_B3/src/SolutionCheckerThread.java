import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class SolutionCheckerThread extends Thread{

    FileContainsChecker[] files;

    String OUTpath;
    String SOLUTIONpath;

    SolutionCheckerThread(FileContainsChecker[] files, String OUTpath, String SOLUTIONpath){
        this.OUTpath = OUTpath;
        this.SOLUTIONpath = SOLUTIONpath;
        this.files = files;

        start();
    }
    public void run(){
        while(!allChecked()){
            for(FileContainsChecker f : files){
                if (!f.isChecked && f.isCorrectIn && f.isSolved){
                    try {
                        check(f);
                        f.isChecked = true;
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                else if (!f.isChecked && !f.isCorrectIn && f.isSolved){
                    f.isChecked = true;
                }
            }
        }
        for(FileContainsChecker f : files){
            f.print();
        }
    }
    void check(FileContainsChecker f) throws IOException {
        BufferedReader out = new BufferedReader(new FileReader( OUTpath
                + "out" + (f.ind ==0 ? "" : f.ind) + Main.prefOUT));
        BufferedReader solve = new BufferedReader(new FileReader( SOLUTIONpath
                + "solution" + (f.ind ==0 ? "" : f.ind) + Main.prefOUT));

        String o = out.readLine();
        String s = solve.readLine();
        while(s != null || o != null){

            if (s == null || o == null || s.compareTo( o ) != 0 ){
                f.isCorrectOut = false;
                out.close();
                solve.close();
                return;
            }
            o = out.readLine();
            s = solve.readLine();
        }
        out.close();
        solve.close();
    }

    boolean allChecked(){
        for(FileContainsChecker f : files){
            if (!f.isChecked){
                return false;
            }
        }
        return true;
    }
}
