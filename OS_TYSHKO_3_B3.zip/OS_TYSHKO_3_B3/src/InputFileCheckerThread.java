import java.io.*;
import java.util.StringTokenizer;

class InputFileCheckerThread extends Thread{
    String in_path;
    FileContainsChecker[] files;
    InputFileCheckerThread(FileContainsChecker[] files, String path){
        this.files = files;
        this.in_path = path;
        start();
    }

    public void run() {
        for (FileContainsChecker file : files) {
            try {
                String filename = in_path +"in" + (file.ind ==0 ? "" : file.ind) + Main.prefIN;
                BufferedReader reader = new BufferedReader(new FileReader(filename));
                StringTokenizer NK = new StringTokenizer(reader.readLine());

                int N = Integer.parseInt(NK.nextToken());
                int K = Integer.parseInt(NK.nextToken());
                if (N < 2 || N > 10000   ||     K<1 || K > 10000000){
                    file.isCorrectIn = false;
                }

                for (int i = 0; i < N && file.isCorrectIn; i++) {
                    String line = reader.readLine();
                    StringTokenizer st;
                    if (line == null){

                        file.isCorrectIn = false;
                    }
                    else {
                        st = new StringTokenizer(line);


                        if (st.countTokens() != N) {
                            file.isCorrectIn = false;
                        }
                        for (int j = 0; j < N && file.isCorrectIn; j++) {
                            if (Integer.parseInt(st.nextToken()) < 0) {
                                file.isCorrectIn = false;
                            }
                        }
                    }
                }
                if (reader.readLine() != null) {
                    file.isCorrectIn = false;
                }
                reader.close();
                System.out.println("Корректные данные \"in" + file.ind + Main.prefIN + "\": " + file.isCorrectIn);
                file.isCheckedIn = true;

                sleep(100);

            } catch (IOException | InterruptedException e) {
                file.isCorrectIn = false;
                file.isCheckedIn = true;
                file.NoFound = true;
                e.printStackTrace();
            }
        }
    }
}
