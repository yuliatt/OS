import java.io.IOException;

public class MainThread extends Thread{

    FileContainsChecker[] files;
    String in_path;
    String solve_path;

    MainThread(FileContainsChecker[] files, String in_path, String solve_path){
        this.files = files;
        this.in_path = in_path;
        this.solve_path = solve_path;
        start();
    }
    public void run(){

        while(!allSolved() ){
            while(Main.STOP_MAIN_THREAD){
                try {
                    System.out.println("Поток спит");
                    sleep(2000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            for (FileContainsChecker file : files){
                if (file.isCorrectIn && file.isCheckedIn && !file.isSolved){
                    Graph g = new Graph(file, in_path, solve_path);
                    try {
                        g.solution();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                if (!file.isCorrectIn && file.isCheckedIn){
                    file.isSolved = true;
                }
            }
            try {
                sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

    }
    boolean allSolved(){
        for (FileContainsChecker file : files){
            if (!file.isSolved){
                return false;
            }
        }
        return true;
    }
}
