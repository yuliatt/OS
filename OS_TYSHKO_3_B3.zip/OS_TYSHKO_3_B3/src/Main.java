import java.io.IOException;
import java.util.Scanner;

public class Main {

    public static String INpath = "C:\\Users\\User\\Desktop\\OS_TYSHKO_3_B3\\tests";
    public static String OUTpath = "C:\\Users\\User\\Desktop\\OS_TYSHKO_3_B3\\tests";
    public static String SOLUTIONpath = "C:\\Users\\User\\Desktop\\OS_TYSHKO_3_B3\\tests";

    /*for local usage
    public static String INpath = "tests";
    public static String OUTpath = "tests";
    public static String SOLUTIONpath = "tests";*/

    public final static String prefIN = ".IN";
    public final static String prefOUT = ".OUT";



    public static boolean STOP_MAIN_THREAD = false;

    public static FileContainsChecker[] files;
    public static int fileСounter = 1;

    public static void main(String[] args) throws IOException, InterruptedException {
        Scanner console = new Scanner(System.in);
        do{
            printerr("Для прекращения работы или остановки MAIN_THREAD напишите что-нибудь в консоль");
            print("Введите 0 для начала работы программы: ");
            String root  = console.next();
            if (root.compareTo("0") == 0){
                INpath += "\\in\\";
                OUTpath += "\\out\\";
                SOLUTIONpath += "\\solutions\\";
                fileСounter = 5;
            }
            else{
                INpath = root + "\\";
                OUTpath = root + "\\";
                SOLUTIONpath = root + "\\";
                fileСounter = 1;
            }

        }while(fileСounter <= 0);

        // проверка файлов
        files = new FileContainsChecker[fileСounter];
        for(int i = 0; i < fileСounter; i++) {
            files[i] = new FileContainsChecker(i);
        }


        InputFileCheckerThread inputChekerThread = new InputFileCheckerThread(files, INpath);
        MainThread mainThread = new MainThread(files, INpath, SOLUTIONpath);
        SolutionCheckerThread solveCheckerThread = new SolutionCheckerThread(files, OUTpath, SOLUTIONpath);

        while (mainThread.isAlive()){
            console.next();
            if (mainThread.isAlive()) {
                println("MAIN_THREAD: работа прервана");
                STOP_MAIN_THREAD = true;
                console.next();
                println("MAIN_THREAD: работа возобновлена");
                STOP_MAIN_THREAD = false;
            }
        }

        solveCheckerThread.join();
    }
    static void print(String msg){
        System.out.print(msg);
    }
    static void println(String msg){
        System.out.println(msg);
    }
    static void printerr(String msg){
        System.err.println(msg);
    }
}
