public class GraphNode {
    GraphEdge[] edges;
    int index;

    GraphNode(int index, int edgesNum){
        this.edges = new GraphEdge[edgesNum];
        this.index = index;
    }
    void initialiseEdge(GraphNode start, int j, int SFWay){
        edges[j] = new GraphEdge(this, start, SFWay);
    }

    void print(){
        System.out.println((index+1) + ":");
        for (GraphEdge edge:edges) {
            edge.print();
        }
    }

}
