public class GraphEdge {

    public GraphNode start;
    public GraphNode finish;
    public int SFway;

    GraphEdge(GraphNode start){

        this.start = start;
        this.finish = null;
        SFway = 0;
    }

    GraphEdge(GraphNode start, GraphNode finish, int SFway){

        this.start = start;
        this.finish = finish;
        this.SFway = SFway;
    }

    void print(){

        System.out.println((start.index+1) + " -> " + (finish.index+1) + " Длина пути: "+ SFway);
    }
}
