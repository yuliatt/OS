package bsu.reading;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ThreadPanel extends JPanel {
    private JTextField fileMaskField;
    private JTextField directoryField;
    private JTextField maxDepthField;
    private JComboBox<FileType> searchTypeComboBox;
    private JCheckBox subdirectoriesCheckBox;
    private JList resultList;
    private JPanel mainPanel;
    private JComboBox<Integer> priorityBox;

    private final FileThread readerThread;

    public ThreadPanel() {
        this.readerThread = new FileThread();
        this.setSize(500, 300);
        this.setVisible(true);
        mainPanel.setVisible(true);
        subdirectoriesCheckBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (subdirectoriesCheckBox.isSelected()) {
                    maxDepthField.setEnabled(true);
                } else {
                    maxDepthField.setEnabled(false);
                }
            }
        });
        searchTypeComboBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                readerThread.setFileType(FileType.valueOf((String)searchTypeComboBox.getSelectedItem()));
            }
        });

    }
    public void initializeThread(){
        String fileMask = fileMaskField.getText();
        readerThread.setFileNameMask(fileMask);

        String maxDepth = maxDepthField.getText();
        readerThread.setMaxDepth(Integer.valueOf(maxDepth));

        String startDirectory = directoryField.getText();
        readerThread.setStartDirectory(startDirectory);

        FileType readingType = FileType.valueOf((String) searchTypeComboBox.getSelectedItem());
        readerThread.setFileType(readingType);
        readerThread.setSearch(subdirectoriesCheckBox.isSelected());

        DefaultListModel<String> listModel = new DefaultListModel<>();
        resultList.setModel(listModel);
        readerThread.setFileList(listModel);
        readerThread.setPriority( Integer.valueOf ((String) priorityBox.getSelectedItem()));
    }
    public void startThread(){
        readerThread.start();
    }
    public FileThread getReaderThread() {
        return readerThread;
    }

}
