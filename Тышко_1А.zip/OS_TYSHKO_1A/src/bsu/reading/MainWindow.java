package bsu.reading;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainWindow extends JFrame {
    private ThreadPanel threadPanel1;
    private ThreadPanel threadPanel2;
    private JPanel mainPanel;
    private JButton startThreadsButton;
    public static ThreadWork work;
    public MainWindow() throws HeadlessException {
        super("Тышко Юлия, 11 группа, 1А");
        work = new ThreadWork();
        setVisible(true);
        setContentPane(mainPanel);
        setSize(1000, 1000);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        startThreadsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                threadPanel1.initializeThread();
                threadPanel2.initializeThread();
                threadPanel1.startThread();
                threadPanel2.startThread();
                startThreadsButton.setEnabled(false);
            }
        });
        setLocationRelativeTo(null);
        setResizable(true);
        pack();
    }


}
