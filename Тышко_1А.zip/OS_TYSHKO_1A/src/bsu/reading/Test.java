package bsu.reading;

import javax.swing.*;

public class Test {
    public static void main(String[] args) {

        new MainWindow();

    }
}
