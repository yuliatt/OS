package bsu.reading;

public enum FileType {
    DIRECTORIES_ONLY, FILES_ONLY, DIRECTORIES_AND_FILES
}
