package bsu.reading;

import bsu.reading.validator.Validator;

import javax.swing.*;
import java.io.File;

public class FileThread extends Thread {
    private FileType fileType;
    private DefaultListModel<String> fileList;
    private int ThreadID;
    private String fileNameMask;
    private String startDirectory;
    private Integer maxDepth;
    private Validator validator;
    private Boolean search;

    private Boolean isStopped = false;

    private static int id_generator = 1;

    public boolean isSuspended() {
        return isSuspended;
    }

    private boolean isSuspended = false;

    public FileThread() {
        this.ThreadID = id_generator++;
        validator = new Validator();
    }

    public FileThread(DefaultListModel<String> fileList) {
        this.fileList = fileList;
    }

    public void setFileType(FileType fileType) {
        this.fileType = fileType;
    }

    public void setSearch(Boolean search) {
        this.search = search;
    }

    public void setFileNameMask(String fileNameMask) {
        this.fileNameMask = fileNameMask;
    }

    public void setFileList(DefaultListModel<String> fileList) {
        this.fileList = fileList;
    }

    public void setStopped(Boolean stopped) {
        isStopped = stopped;
    }

    public void setStartDirectory(String startDirectory) {
        this.startDirectory = startDirectory;
    }

    public void setMaxDepth(Integer maxDepth) {
        this.maxDepth = maxDepth;
    }

    private void suspendThread() throws InterruptedException {
        if (isSuspended) {
            synchronized (this) {
                MainWindow.work.appendLog("THREAD: " + ThreadID + " PAUSED");
                while (isSuspended) {
                    wait();
                }
                MainWindow.work.appendLog("THREAD: " + ThreadID + " UNPAUSED");
            }
        }
    }

    private void recursiveSearch(Integer counter, File directory) throws InterruptedException {
        if (counter <= maxDepth && !isStopped) {
            File[] filesCheck = directory.listFiles();
            if (filesCheck != null) {
                for (File file : filesCheck) {
                    Thread.sleep(30);
                    suspendThread();
                    if (isStopped) {
                        return;
                    }
                    switch (fileType) {
                        case DIRECTORIES_AND_FILES:
                            if (validator.isValid(file, fileNameMask)) {
                                fileList.addElement(file.getName());
                                synchronized (MainWindow.work) {
                                    MainWindow.work.appendLog("THREAD: " + ThreadID +
                                            " FOUND F OR D: " + file.getName());
                                }
                            }
                            if (file.isDirectory() && search) {
                                recursiveSearch(counter + 1, file);
                            }
                            break;
                        case DIRECTORIES_ONLY:
                            if (file.isDirectory()) {
                                if (validator.isValid(file, fileNameMask)) {
                                    String filename = file.getName();

                                    fileList.addElement(filename);
                                    synchronized (MainWindow.work) {
                                        MainWindow.work.appendLog("THREAD: " + ThreadID +
                                                " FOUND D: " + filename);
                                    }
                                }
                                if (search) {
                                    recursiveSearch(counter + 1, file);
                                }
                            }
                            break;
                        case FILES_ONLY:
                            if (validator.isValid(file, fileNameMask) && file.isFile()) {

                                fileList.addElement(file.getName());
                                synchronized (MainWindow.work) {
                                    MainWindow.work.appendLog("THREAD: " + ThreadID +
                                            " FOUND F: " + file.getName());
                                }
                            }
                            if (search) {
                                recursiveSearch(counter + 1, file);
                            }
                            break;
                    }

                }
            }
        }
    }

    @Override
    public void run() {
        super.run();
        MainWindow.work.appendLog("THREAD: " + ThreadID + " launched");
        try {
            File startingFile = new File(startDirectory);
            recursiveSearch(0, startingFile);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        if (!isStopped) {
            MainWindow.work.appendLog("THREAD: " + ThreadID + " finished the search");
        } else {

            MainWindow.work.appendLog("THREAD: " + ThreadID + " stopped");
        }
    }

    public void setSuspended(boolean suspended) {
        isSuspended = suspended;
    }
}
