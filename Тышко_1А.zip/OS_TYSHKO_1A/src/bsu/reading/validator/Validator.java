package bsu.reading.validator;

import java.io.File;

public class Validator {
    public boolean isValid(File fileToCheck, String mask){
        String fileName = fileToCheck.getName();
        return fileName.matches("^" + mask + "$");
    }

}
