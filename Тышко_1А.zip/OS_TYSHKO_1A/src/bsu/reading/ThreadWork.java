package bsu.reading;

import javax.swing.*;

public class ThreadWork extends JFrame {
    private JPanel contentPane;
    private JTextArea logArea;
    private JScrollPane scrollPane;

    public ThreadWork() {
        super("Threads Work");
        setSize(400,400);
        setLocationRelativeTo(null);
        setContentPane(contentPane);
        setVisible(true);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    }
    public void appendLog(String string){
        logArea.append(string + '\n');
    }
}
